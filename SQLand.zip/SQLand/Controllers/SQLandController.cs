﻿using SQLand.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SQLand.Controllers
{
    public class SQLandController : Controller
    {
        // GET: SQLand
        public ActionResult Index()
        {
            //var SqlLand = new SQLandEntities();
            //return View(SqlLand.Database);

           // SQLandEntities db = new SQLandEntities();
           // List<> model = db.ATTRACTIONs.ToList();
           // ViewBag.Message = "This view is loaded from database!";
            return View();
        }

        // GET: SQLand Query 1
        public ActionResult Query1()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query1> model = db.Query1.ToList();
            ViewBag.Message = "-- QUERY 1: <br>Select the names of Attractions that are in either" +
                "--HorrorLand or SpaceLand: <br><br>use SQLand; <br>SELECT Name <br>FROM ATTRACTION <br>WHERE Attr_Park_Section = " +
                "'HorrorLand' UNION <br>SELECT Name <br>FROM ATTRACTION <br>WHERE Attr_Park_Section = 'SpaceLand'";
            return View(model);
        }

        // GET: SQLand Query 2
        public ActionResult Query2()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query2> model = db.Query2.ToList();
            ViewBag.Message = "-- QUERY 2: Select the name of guests that check in during the summer, <br>" +
                "--i.e between May 1, 2016 and September 1, 2016: <br><br>use SQLand; <br>SELECT Guest_Name <br>FROM HOTEL" + 
                "WHERE Check_In_Date >= '2016-05-01' INTERSECT <br>SELECT Guest_Name <br>FROM HOTEL <br>"+
                "WHERE Check_Out_Date <= '2016-09-01'";
            return View(model);
        }

        // GET: SQLand Query 3
        public ActionResult Query3()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query3> model = db.Query3.ToList();
            ViewBag.Message = "-- QUERY 3: Select the name of a ticket holder at the park in Ohio, <br>" +
                "--that are not staying in the Ohio park's hotel: <br><br>use SQLand; SELECT Holder_Name <br>" +
                "FROM TICKET <br>WHERE Ticket_Location_ID = 'PRKOH' <br>EXCEPT <br>SELECT Guest_Name <br>FROM HOTEL" +
                "WHERE Hotel_Park_ID = 'PRKOH'";
            return View(model);
        }

        // GET: SQLand Query 4
        public ActionResult Query4()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query4> model = db.Query4.ToList();
            ViewBag.Message = "-- QUERY 4: Select the ID of every Merchandise location <br>--that sells every item: <br><br>use SQLand;" +
                "SELECT Store_ID <br>FROM MERCHANDISE <br>WHERE NOT EXISTS( <br>SELECT Item_ID <br>FROM ITEM <br>WHERE NOT EXISTS(" +
                "SELECT * <br>FROM SELLS_MERCH <br>WHERE Sell_Merch_Store_ID = Store_ID AND Sell_Merch_Item_ID = Item_ID))";
            return View(model);
        }

        // GET: SQLand Query 5
        public ActionResult Query5()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query5> model = db.Query5.ToList();
            ViewBag.Message = "-- QUERY 5: Retrieve the number of employees that work <br>-- for each department. <br><br>use SQLand;" +
                "<br>SELECT Employee_Dept_ID as Dept, COUNT(Employee_ID) as EmpCount <br>INTO Query5 <br>FROM EMPLOYEE" +
                "<br>GROUP BY Employee_Dept_ID";
            return View(model);
        }

        // GET: SQLand Query 6
        public ActionResult Query6()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query6> model = db.Query6.ToList();
            ViewBag.Message = "-- QUERY 6: Retrieve the average price of an item sold by by each park location: <br><br>use SQLand;" +
                "<br>SELECT p.City as Park_City, avg(i.price) as Average_Item_Price <br>FROM PARK as p, SECTION as s, MERCHANDISE as m," +
                "<br>SELLS_MERCH as sm, ITEM as i <br>WHERE p.Location_ID = s.Section_Location_ID AND s.Name = m.Merch_Park_Section AND" +
                "<br>m.Store_ID = sm.Sell_Merch_Store_ID AND sm.Sell_Merch_Item_ID = i.Item_ID <br>GROUP BY City";
            return View(model);
        }

        // GET: SQLand Query 7
        public ActionResult Query7()
        {
            SQLandEntities1 db = new SQLandEntities1();
            List<Query7> model = db.Query7.ToList();
            ViewBag.Message = "-- QUERY 7: Find park experiences with conflicting start times: <br><br>use SQLand;" +
                "<br>SELECT CHARACTER_EXPERIENCE.Exp_ID, LIVE_ENTERTAINMENT.Show_ID <br>FROM CHARACTER_EXPERIENCE" +
                "LEFT JOIN LIVE_ENTERTAINMENT <br>ON CHARACTER_EXPERIENCE.Start_Time = LIVE_ENTERTAINMENT.Start_Time";
            return View(model);
        }

        // GET: SQLand/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SQLand/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SQLand/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SQLand/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SQLand/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SQLand/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SQLand/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
