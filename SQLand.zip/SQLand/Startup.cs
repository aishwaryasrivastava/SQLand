﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SQLand.Startup))]
namespace SQLand
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
